# CAST Corona clicker

This plugin retrieve the canvas coordinates and use them to open ***Corona @ CAST Atlas*** <img src="https://logo.cast.uark.edu/logo/logo-text-horizontal-light-320x104.png" alt="Lat Lon Tools Plugin" width="64"> (https://corona.cast.uark.edu/) zoomed and located in the location clicked

This plugin was created as part of the EAMENA project to aid in the documentation of archaeological sites. but also as an exploratory tool for the CLaSS project to compare shapes of archaeological sites before the urban growth after 1970.
<div style="text-align:center"><img src="https://eamena.org/sites/default/files/styles/site_logo/public/styles/site_logo/public/eamena/site-logo/eamena_acronym_fullname_leic_arc_durf.png" alt="Eamena logo Plugin" width="250"> - <img src="https://www.durham.ac.uk/media/durham-university/site-assets/image/logo-dark.svg" alt="durham logo Plugin" width="150"></div>

